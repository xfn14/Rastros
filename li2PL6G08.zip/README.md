<div align="center">
    <img src="https://i.imgur.com/GOGaHkq.jpg" align="center" alt="MIEI">
    <br>
    <br>
    <strong><i>🔴 Rastros - Laboratórios de Informática II</i></strong>
    <br>
    <br>
    <br>
    <a href="https://github.com/andreubita/li2-201920/issues">
        <img src="https://img.shields.io/github/issues/andreubita/li2-201920.svg?style=for-the-badge&colorB=37f149" alt="Issues">
    </a>
    <a href="https://github.com/andreubita/li2-201920/pulls">
        <img src="https://img.shields.io/github/issues-pr/andreubita/li2-201920?style=for-the-badge&colorB=37f149" alt="Pull Requests">
    </a>
</div>
<br>
<br>

## PL6 - Grupo 8 -MIEI 🧔
- André Filipe Novais Vaz - A93221
- Ricardo Lopes Santos Silva - A93195
- Benjamim Meleiro Rodrigues - A93323

## Relatórios 📝
- [Guião 5](https://github.com/andreubita/li2-201920/blob/master/relatorios/guiao5/README.md)
- [Guião 6](https://github.com/andreubita/li2-201920/blob/master/relatorios/guiao6/README.md)
- [Guião 7](https://github.com/andreubita/li2-201920/blob/master/relatorios/guiao7/README.md)
- [Guião 8](https://github.com/andreubita/li2-201920/blob/master/relatorios/guiao8/README.md)
- [Guião 9](https://github.com/andreubita/li2-201920/blob/master/relatorios/guiao9/README.md)
- [Guião 10](https://github.com/andreubita/li2-201920/blob/master/relatorios/guiao10/README.md)

## Como Jogar 🎯
<a href="http://www.youtube.com/watch?feature=player_embedded&v=a_5_H9-Rmg0" target="_blank">
    <img src="http://img.youtube.com/vi/a_5_H9-Rmg0/0.jpg" alt="Jogo Rastros Video" width="240" height="180" border="10"/>
</a>
